## Como utilizar o github code spaces

1. Dentro do seu repositório, apertar `.` ou trocar a url de `.com` para `.dev` para abrir o VSCode na web
2. Clicar no menu hambuger, selecionar terminal, novo terminal para abrir um terminal novo
3. Clicar no primeiro botão verde do terminal, para utilizar um ambiente cloud do codespaces para desenvolver, e selecionar a máquina mais básica de 2 cores. Irá abrir outra aba
4. Na nova aba, um terminal ficará disponível na raiz do seu repositório
5. É possível rodar o comando `npx http-server .` para subir um servidor http dos seus arquivos, permitindo que visualize as mudanças feitas no código
6. Também pode adicionar a extensao Live server no Vscode para subir um servidor.
