## Referências:

### Livros:

- [HTML5 e CSS3: guia prático e visual - Elizabeth Castro / Bruce Hyslop](https://www.amazon.com.br/dp/8576088037)
- [Guia de orientação e desenvolvimento de sites: HTML, XHTML, CSS e Javascript/Jscript - José A. Manzano / Suely Alves de Toledo](https://www.amazon.com.br/dp/8536501901)

### Sites/Documentações:

- [W3C](https://www.w3.org/), [MDN](https://developer.mozilla.org/pt-BR/), [W3Schools](https://www.w3schools.com/), [Can I use](https://caniuse.com/), [Open Graph](https://ogp.me/).
