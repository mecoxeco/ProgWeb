A partir do arquivo [atividade-pokemon-29-02.html](https://github.com/TI-UNICESUMAR/2024-programacao-web-esoft5s-b/blob/main/2024-03-07/exemplos/atividade-pokemon-29-02.html), efetuar os seguintes ajustes nos estilos:

Centralizar o conteúdo da tag **main** utilizando **Flexbox**;  
Utilizar Flexbox nas tags de **section** e **article**;  
Remover o **text-align: center** do **header** e utilizar **Flexbox**;  
Deixar a nossa **nav** responsiva, utilizando **Flexbox**;  
Deixar a nossa **lista de evoluções** responsiva, utilizando **Flexbox**;  
Remover **layout shifting** no carregamento das imagens;  

O resultado da atividade deverá refletir no [Github Pages](https://github.com/TI-UNICESUMAR/2024-programacao-web-esoft5s-b/blob/main/2024-03-05/aula.md) do seu repositório.
