[Grid template areas](https://codepen.io/satinp/pen/poBJWxx)
